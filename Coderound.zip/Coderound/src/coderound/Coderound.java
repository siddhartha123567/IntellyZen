/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coderound;



/**
 *
 * @author Sid
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Coderound {

	public static void main(String[] args) throws SQLException {
//boolean x = false;
		String url = "jdbc:mysql://localhost:3306/coderdata";
		String user = "root";
		String password = "mostwanted";
char key;
		Connection myConn = null;
		PreparedStatement myStmt = null;
                Statement stmt=null;
myConn = DriverManager.getConnection(url, user, password);
		Scanner scanner = null;
                //char key=keyboard.next().charAt(0);
                Scanner keyboard = new Scanner(System.in);
           do{       
                   
                   System.out.println("Enter A.Add\n B.Find \n C.List\n");
                    key=keyboard.next().charAt(0);
          
                switch(key) {
         case 'A':
             try{
            scanner = new Scanner(System.in);     
        System.out.print("add ");
     //   scanner = new Scanner(System.in);    
	String productname = scanner.nextLine();
             String sql = "insert into product "
					+ "(productname)" + " values(?)";

			myStmt = myConn.prepareStatement(sql);
 			myStmt.setString(1, productname);
                        myStmt.executeUpdate();

			System.out.println("Insert complete.");
                        } catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close();
			}

			if (scanner != null) {
				scanner.close();
			}
		}
                
            break;
         case 'B' : scanner = new Scanner(System.in);     
        System.out.print("find \t ");
        String pn = scanner.nextLine();
             String sql="select productname from product";
           //  System.out.println(sql);
             stmt = myConn.createStatement(ResultSet.CONCUR_UPDATABLE, ResultSet.TYPE_SCROLL_INSENSITIVE);
             ResultSet rs=stmt.executeQuery(sql);
           //  ArrayList <String[]> result = new ArrayList<String[]>();
//ResultSet rs = stat.executeQuery( "SELECT ..." );
//int columnCount = rs.getMetaData().getColumnCount();
             String[] row = new String[1];
while(rs.next())
{
 //   String[] row = new String[1];
    for (int i=0; i <1 ; i++)
    {
       row[i] = rs.getString(i + 1);
       System.out.println(""+row[i]);
    }
   // result.add(row);
}

             int j= 0;
Set<String> teamSet = new TreeSet<>();
Collections.addAll(teamSet,row);
//System.out.println(""+pn);
if (teamSet.contains(pn)) {
    System.out.println("product: " + pn);
} else {
    System.out.println("no match");
}
    for ( int i = 0 ; i < 1; i++){
        int k = pn.length();
     
        String newstring = row[i].substring(i,i+k); 
        if(newstring.equals(pn))
            j++;  
        }

    System.out.printf("%d Count is", j);  
                     break;
         case 'C' ://scanner = new Scanner(System.in);     
            System.out.println("Displaying  all the products");
             String sql2 = "select productname from product ";
stmt =myConn.createStatement(ResultSet.CONCUR_UPDATABLE, ResultSet.TYPE_SCROLL_INSENSITIVE);
 ResultSet rs1 = stmt.executeQuery(sql2);
            while (rs1.next()) {
                System.out.println(rs1.getString(1));
            }


            break;
        
         default :
            System.out.println("Invalid choice");
                
                }       
	 }while(key !='D');   	
        }
           }
